import React from 'react'

const Sports = () => {
  return (
    <> 
    <div>Sports</div>
    <h1>welcome to sports day</h1>
    <h2>following are the games to be conducted</h2>
    <ol>
        <li>high jump</li>
        <li>cricket</li>
        <li>throw ball</li>
        <li>volleyball</li>    
        </ol>
    </>

  )
}

export default Sports