import logo from "./logo.svg";
import "./App.css";
import Electronics from "./components/Electronics";
import Personal from "./components/Personal";
import Entertainment from "./components/Entertainment";
import Amazon from "./components/Amazon";
import Medicines from "./components/Medicines";
import Sports from "./components/Sports";
import { BrowserRouter as Router, Route, Routes} from "react-router-dom";

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Amazon />} />
        <Route path="/electronics" element={<Electronics />} />
        <Route path="/personal" element={<Personal />} />
        <Route path="/entertainment" element={<Entertainment />} />
        <Route path="/medicines" element={<Medicines />} />
        <Route path="/sports" element={<Sports />} />
      </Routes>
    </Router>
  );
}

export default App;
