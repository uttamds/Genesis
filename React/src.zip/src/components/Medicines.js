import React from 'react'

const Medicines = () => {
  return (
    <>
    <div>Medicines</div>
    <h1>welcome to our medical store</h1>
    <h2>open from 9:00 A.M. to 9:00 P.M.</h2>
    <h3>sunday timings from 9:00 A.M. to 1:00 P.M. only</h3>
    </>
  )
}

export default Medicines