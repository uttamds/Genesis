import React from 'react'

const Levis = () => {
  return (

    <>
    <div>This is LEVIS bangalore</div>
    <h1>Jeans that fit you!!!</h1>
    
    </>
    
  )
}

export default Levis