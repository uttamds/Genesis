import React from "react";
import { Link } from "react-router-dom";

const Amazon = () => {
  return (
    <>

    <h1>AMAZON INDIA</h1>
      <div>
        <h2>Categories</h2>
        <ul>
          <li>
            <Link to="/electronics">Electronics</Link>
          </li>
          <li>
            <Link to="/personal">Personal</Link>
          </li>
          <li>
            <Link to="/entertainment">Entertainment</Link>
          </li>
          <li>
            <Link to="/medicines">Medicines</Link>
          </li>
          <li>
            <Link to="/sports">Sports</Link>
          </li>
        </ul>
      </div>
    </>
  );
};

export default Amazon;
