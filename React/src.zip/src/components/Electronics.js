import React from "react";
import logo from "./Emall.jpg";
import { useState } from "react";

const Electronics = () => {
  const [tvQty, setTvQty] = React.useState(0);
  const [laptopQty, setLaptopQty] = React.useState(0);
  const [mobileQty, setMobileQty] = React.useState(0);

  
  return (
    <>
      <img src={logo} className="" alt="logo"></img>
      
      <div>
        <h2>Electronics Section</h2>
        <ul>
          <li>
            TV{"     "}
            <button onClick={() => setTvQty(tvQty - 1)}>
              -
            </button>
            <span><button>{tvQty}</button></span>
            <button onClick={() => setTvQty(tvQty + 1)}>
              +
            </button>
          </li>
          <li>
          Laptop{" "}
            <button onClick={() => setLaptopQty(laptopQty - 1)}>
              -
            </button>
            <span><button>{laptopQty}</button></span>
            <button onClick={() => setLaptopQty(laptopQty + 1)}>
              +
            </button>
          </li>
          <li>
          Mobile{" "}
            <button onClick={() => setMobileQty(mobileQty - 1)}>
              -
            </button>
            <span><button>{mobileQty}</button></span>
            <button onClick={() => setLaptopQty(mobileQty + 1)}>
              +
            </button>
          </li>
         
        </ul>
      </div>
    </>
  );
}

export default Electronics;
